JOAN'S KITCHENETTE - FIXED PWA

Upload the CONTENTS of this folder to the ROOT of your GitHub Pages repository.
index.html must be in the repository root.

Then open the GitHub Pages HTTPS URL.
On iPhone: Safari -> Share -> Add to Home Screen.
On Android: Chrome -> Install/Add to Home screen.
On Windows: Edge/Chrome -> Install app.

Camera access requires HTTPS (GitHub Pages provides HTTPS).
